# Power BI Project Files

## Important: one folder is missing from this commit

`Finance_FPA_Dashboard.pbip` is only a **pointer file**. It is 4 KB of JSON whose entire job
is to name the folder that holds the real report:

```json
"artifacts": [ { "report": { "path": "Finance FPA Dashboard.Report" } } ]
```

That folder — `Finance FPA Dashboard.Report/` — contains the actual report definition and it
is **not yet in this repository**. Without it, Power BI Desktop will fail to open the `.pbip`
with a missing-artifact error.

## How to complete this folder

On the machine where you built the report, the `.pbip` sits next to its companion folder(s):

```
Finance_FPA_Dashboard.pbip
Finance FPA Dashboard.Report/          <-- copy this whole folder here
Finance FPA Dashboard.SemanticModel/   <-- and this one, if it exists
```

Copy the entire folder(s) into `powerbi/`, keeping the exact folder names — the `.pbip`
matches them by name, so renaming breaks the link. The result should look like:

```
powerbi/
├── Finance_FPA_Dashboard.pbip
└── Finance FPA Dashboard.Report/
    ├── .pbi/
    │   └── localSettings.json        (git-ignored - machine specific)
    ├── definition.pbir
    ├── report.json
    └── StaticResources/
```

If your project also has a `.SemanticModel` folder, it holds the data model as `.tmdl` files.
Commit it too — it is where your tables, relationships and DAX measures actually live.

Then commit:

```bash
git add powerbi/
git commit -m "Add Power BI report definition"
```

## Why PBIP instead of PBIX

| | `.pbix` | `.pbip` |
|---|---|---|
| Storage | Single binary blob | Folder of JSON / TMDL text files |
| Git diff | Unreadable | Line-by-line readable |
| Code review | Not possible | Reviewable in a pull request |
| Merge conflicts | Whole file conflicts | Resolvable per file |

You chose the right format for a Git-hosted project. `.pbix` is deliberately excluded in
`.gitignore` so the repo keeps a single source of truth — delete that line if you also want
a downloadable `.pbix` for people without Power BI Desktop.

## Opening the project

1. Power BI Desktop, June 2024 release or later.
2. *File → Options and settings → Options → Preview features* → tick
   **Power BI Project (.pbip) save option**. Restart Desktop.
3. Open `Finance_FPA_Dashboard.pbip`.
4. Repoint the source: *Transform data → Data source settings → Change Source* →
   `data/source/Financial_Sample.xlsx` in your clone. The saved path is absolute and will
   point at the original author's machine.
