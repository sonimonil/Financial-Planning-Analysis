# Dashboard Screenshots

Drop PNG exports of each report page here, then reference them from the root `README.md`.

Suggested filenames:

| File | Page |
|---|---|
| `01-executive-summary.png` | Executive Summary |
| `02-profitability.png` | Profitability |
| `03-discount-analysis.png` | Discount Analysis |
| `04-geography-product.png` | Geography & Product |

To capture: open the report in Power BI Desktop, press `Ctrl` + `Shift` + `C` for a clean
full-page copy, or use *File → Export → Export to PDF* and convert pages to PNG.

Then add to the root README, just under the badges:

```markdown
## Dashboard

![Executive Summary](docs/images/01-executive-summary.png)
![Profitability](docs/images/02-profitability.png)
```

Screenshots matter more than anything else in this repo for a portfolio. Most people who
open a GitHub page will not install Power BI Desktop to see your work — the image is the
work, as far as they are concerned. Keep each under about 500 KB so the page loads fast.
